// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
#include "googletest/googletest/include/gtest/gtest.h"

#include <vector>
#include <ctime>
#include <cstdlib>
#include <cassert>

// The global test environment setup and tear down
// You should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    // Initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// Create our test class to house shared data between tests
// You should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // Create a smart pointer to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // Create a new collection to be used in the test
    collection.reset(new std::vector<int>);
  }

  void TearDown() override
  { // Erase all elements in the collection, if any remain
    collection->clear();
    // Free the pointer
    collection.reset(nullptr);
  }

  // Helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
// CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
// CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // Is the collection created
  ASSERT_TRUE(collection);

  // If empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // Is the collection empty?
  ASSERT_TRUE(collection->empty());

  // If empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

// TODO: Comment this test out to prevent the test from running
// Uncomment this test to see a failure in the test explorer
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // Is the collection empty?
  EXPECT_TRUE(collection->empty());

  // Add a value
  collection->push_back(42);

  // Is the collection still empty?
  EXPECT_FALSE(collection->empty());

  // Check the size
  EXPECT_EQ(collection->size(), 1);
}

// Test adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  add_entries(5);

  // Check the size
  EXPECT_EQ(collection->size(), 5);
}

// Test that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterOrEqual)
{
  add_entries(0);
  EXPECT_GE(collection->max_size(), collection->size());

  add_entries(1);
  EXPECT_GE(collection->max_size(), collection->size());

  add_entries(5);
  EXPECT_GE(collection->max_size(), collection->size());

  add_entries(10);
  EXPECT_GE(collection->max_size(), collection->size());
}

// Test that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterOrEqual)
{
  add_entries(0);
  EXPECT_GE(collection->capacity(), collection->size());

  add_entries(1);
  EXPECT_GE(collection->capacity(), collection->size());

  add_entries(5);
  EXPECT_GE(collection->capacity(), collection->size());

  add_entries(10);
  EXPECT_GE(collection->capacity(), collection->size());
}

int main(int argc, char** argv)
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
