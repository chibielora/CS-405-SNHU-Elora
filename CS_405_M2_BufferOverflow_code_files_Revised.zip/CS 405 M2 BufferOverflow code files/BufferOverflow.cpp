// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <cstring>

int main() {
    // Print a welcome message
    std::cout << "Buffer Overflow Example" << std::endl;

    // Define the secret account number as a constant string
    const std::string account_number = "CharlieBrown42";

    // Create a character array to store user input
    char user_input[20]; // 20 characters for input

    // Prompt the user for input
    std::cout << "Enter a value (20 characters max): ";

    // Use std::cin.get to read user input character by character
    for (int i = 0; i < sizeof(user_input) - 1; ++i) {
        char c;
        std::cin.get(c);

        if (c == '\n') {
            break; // Stop reading if Enter is pressed
        }

        user_input[i] = c;
    }

    // Null-terminate the user_input string
    user_input[sizeof(user_input) - 1] = '\0';

    // Display the user input
    std::cout << "You entered: " << user_input << std::endl;

    // Check if the user input exceeded the maximum length
    if (strlen(user_input) == sizeof(user_input) - 1) {
        std::cout << "Input too long. Buffer overflow prevented." << std::endl;
    }

    // Print the account number
    std::cout << "Account Number = CharlieBrown42" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
