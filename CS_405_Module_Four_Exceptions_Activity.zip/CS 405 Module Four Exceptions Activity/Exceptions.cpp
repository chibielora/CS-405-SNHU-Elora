#include <iostream>
#include <stdexcept> // Include the standard exception header

// Custom exception class derived from std::exception
class MyCustomException : public std::exception
{
public:
    // Constructor that takes a custom error message
    MyCustomException(const char* message) : msg(message) {}

    // Override the what() method to provide the error message
    const char* what() const noexcept override
    {
        return msg.c_str();
    }

private:
    std::string msg;
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception (e.g., std::runtime_error)
    throw std::runtime_error("An error occurred in do_even_more_custom_application_logic()");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        // Wrap the call to do_even_more_custom_application_logic() with an exception handler
        // that catches std::exception and displays the error message using what()
        do_even_more_custom_application_logic();

        std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Caught a standard exception: " << ex.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception and catch it explicitly in main
    throw MyCustomException("Custom exception thrown in do_custom_application_logic()");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0)
    {
        // TODO: Throw an exception to deal with divide by zero errors using a standard C++ defined exception
        throw std::invalid_argument("Division by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    // TODO: Create an exception handler to capture ONLY the exception thrown by divide

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        // Call the divide() function and catch any exceptions
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Caught a standard exception: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        // Create exception handlers that catch (in this order):
        //  1. Your custom exception
        //  2. std::exception
        //  3. Uncaught exception that wraps the whole main function

        do_division();
        do_custom_application_logic();
    }
    catch (const MyCustomException& ex)
    {
        std::cerr << "Caught custom exception: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Caught a standard exception: " << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Caught an unhandled exception." << std::endl;
    }

    return 0;
}
